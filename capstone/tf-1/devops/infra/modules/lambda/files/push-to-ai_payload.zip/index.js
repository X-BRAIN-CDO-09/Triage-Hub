const AI_ENGINE_URL = process.env.AI_ENGINE_URL || "http://ai-engine.tf1.internal:8080/v1/triage";

const SERVICE_NAME = process.env.SERVICE_NAME || "push-to-ai";
const ENVIRONMENT = process.env.ENVIRONMENT || "unknown";

function log(level, message, correlationId, data = {}) {
  const logEntry = {
    timestamp: new Date().toISOString(),
    level,
    message,
    ServiceName: SERVICE_NAME,
    Environment: ENVIRONMENT,
    TraceId: process.env._X_AMZN_TRACE_ID || "unknown",
    SpanId: "unknown",
    CorrelationId: correlationId || "unknown",
    ...data
  };
  console[level === "error" ? "error" : "log"](JSON.stringify(logEntry));
}

exports.handler = async (event) => {
  log("info", "Processing SQS batch", "unknown", { batchSize: event.Records.length });

  for (const record of event.Records) {
    let correlationId = "unknown";
    if (record.messageAttributes && record.messageAttributes.CorrelationId) {
      correlationId = record.messageAttributes.CorrelationId.stringValue;
    }

    try {
      log("info", "Forwarding message to EKS", correlationId, { messageId: record.messageId });
      
      const payload = JSON.parse(record.body);
      
      const response = await fetch(AI_ENGINE_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Correlation-Id": correlationId !== "unknown" ? correlationId : (payload.correlation_id || "unknown"),
          "X-Tenant-Id": payload.tenant_id || "unknown"
        },
        body: record.body
      });

      if (!response.ok) {
        throw new Error(`EKS Triage Engine returned status: ${response.status}`);
      }

      const result = await response.json();
      log("info", "Successfully triaged incident", correlationId, { EKSResult: result });
      
    } catch (err) {
      log("error", "Failed to forward record to EKS", correlationId, { error: err.message, stack: err.stack });
      // Ném lỗi để SQS đưa vào DLQ hoặc retry
      throw err;
    }
  }

  return { status: "processed" };
};
