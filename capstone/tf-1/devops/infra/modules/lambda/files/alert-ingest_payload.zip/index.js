const { SQSClient, SendMessageCommand } = require("@aws-sdk/client-sqs");
const sqsClient = new SQSClient({});
const QUEUE_URL = process.env.SQS_QUEUE_URL;

const SERVICE_NAME = process.env.SERVICE_NAME || "alert-ingest";
const ENVIRONMENT = process.env.ENVIRONMENT || "unknown";

function log(level, message, correlationId, data = {}) {
  const logEntry = {
    timestamp: new Date().toISOString(),
    level,
    message,
    ServiceName: SERVICE_NAME,
    Environment: ENVIRONMENT,
    TraceId: process.env._X_AMZN_TRACE_ID || "unknown",
    SpanId: "unknown",
    CorrelationId: correlationId || "unknown",
    ...data
  };
  console[level === "error" ? "error" : "log"](JSON.stringify(logEntry));
}

exports.handler = async (event) => {
  let correlationId = "unknown";

  try {
    if (event.headers && event.headers['x-correlation-id']) {
      correlationId = event.headers['x-correlation-id'];
    }

    log("info", "Received alert ingestion request", correlationId, { event });

    if (!event.body) {
      log("error", "Missing request body", correlationId);
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Missing request body" })
      };
    }

    const payload = JSON.parse(event.body);
    if (payload.correlation_id) {
        correlationId = payload.correlation_id;
    }
    
    // Gửi message vào SQS
    const command = new SendMessageCommand({
      QueueUrl: QUEUE_URL,
      MessageBody: event.body,
      MessageAttributes: {
        TenantId: {
          DataType: "String",
          StringValue: payload.tenant_id || "unknown"
        },
        CorrelationId: {
          DataType: "String",
          StringValue: correlationId
        }
      }
    });

    const result = await sqsClient.send(command);
    log("info", "Successfully pushed alert to SQS", correlationId, { MessageId: result.MessageId });

    return {
      statusCode: 202,
      body: JSON.stringify({
        status: "Accepted",
        message_id: result.MessageId
      })
    };
  } catch (err) {
    log("error", "Error in alert ingest", correlationId, { error: err.message, stack: err.stack });
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Internal Server Error" })
    };
  }
};
